UPDATE imdb_movies SET year = '1999' WHERE year = '1998-1999'
